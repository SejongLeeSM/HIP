package com.example.helperinproject;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;
import android.widget.TextView;

public class DrawLine extends View{

	float startX;
	float startY;
	float stopX;
	float stopY;
	int color=0x66cdaa;
	public DrawLine(Context context,Node n1,Node n2){
		super(context);
		startX=n1.getX()+70;
		startY=n1.getY()+70;
		stopX=n2.getX()+70;
		stopY=n2.getY()+70;
	}
	public void setPntColor(int i){
		color=i;
	}



public void onDraw(Canvas canvas){
	
	 Paint pnt=new Paint();
	 pnt.setColor(color);
	 pnt.setAlpha(20);
	 pnt.setStrokeWidth(20);
	 canvas.drawLine(startX, startY, stopX, stopY, pnt);
	 
	 
}

}