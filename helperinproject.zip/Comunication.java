
package com.example.helperinproject;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import android.content.Context;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;

public class Comunication 
  {

   private String result;
   private String message;
   private String token;
   private String userId;
   private List<String> team_id;
   private List<String> team_name;
   private List<String> user_id;
   private List<String> user_number;
   private List<List<String>> textData;
   private List<List<String>> nodeId;
   private List<List<String>> writeUser;
   private List<List<String>> time;
   Context context;
   
   
   public Comunication(Context context,String url,String key){
      
      this.context=context;
      comunication(context,url,key);
      
      
   }
   
   public void comunication(Context context,String url,String key){
   try 
   {   HttpClient client = new DefaultHttpClient();
      HttpGet get = new HttpGet(url);
     HttpResponse responseGet = client.execute(get);
     HttpEntity resEntityGet = responseGet.getEntity();
     if (resEntityGet != null) 
     {
        
        if(key.equals("login"))
        loginParsing(EntityUtils.toString(resEntityGet));
        else if(key.equals("teamlist"))
           teamListParsing(EntityUtils.toString(resEntityGet));
        else if(key.equals("teamsignup"))
           teamSignUpParsing(EntityUtils.toString(resEntityGet));
        else if(key.equals("createteam"))
           createTeamParsing(EntityUtils.toString(resEntityGet));
        else if(key.equals("memberlist"))
           memberListParsing(EntityUtils.toString(resEntityGet));
        else if(key.equals("mainnode"))
           mainNodeParsing(EntityUtils.toString(resEntityGet));
        else if(key.equals("childnode"))
           childNodeParsing(EntityUtils.toString(resEntityGet));
        else if(key.equals("getnode"))
           getNodeParsing(EntityUtils.toString(resEntityGet));
        else if(key.equals("deletenode"))
           deleteNodeParsing(EntityUtils.toString(resEntityGet));
        else if(key.equals("addtimetable"))
           addTimeTableParsing(EntityUtils.toString(resEntityGet));
        else if(key.equals("deltimetable"))
           delTimeTableParsing(EntityUtils.toString(resEntityGet));
        else if(key.equals("teamtimetable"))
           getTeamTimeTableParsing(EntityUtils.toString(resEntityGet));
        else if(key.equals("likenode"))
        	 plusLikeParsing(EntityUtils.toString(resEntityGet));
        else if(key.equals("sosonode"))
        	plusSosoParsing(EntityUtils.toString(resEntityGet));
        else if(key.equals("getscore"))
        	getScoreParsing(EntityUtils.toString(resEntityGet));
        }
     
     
     else{
        Toast.makeText(context,"���ͳ� ���� Ȯ��", Toast.LENGTH_LONG).show(); 
     }
   } catch (Exception e) { e.printStackTrace();
    Toast.makeText(context,e.toString(), Toast.LENGTH_LONG).show();
   
   }
}
   
   
   private void getScoreParsing(String info) {
	    JSONParser jsonParser = new JSONParser();
	         try {
	              JSONObject jObj = (JSONObject)jsonParser.parse(info);
	               result=jObj.get("result").toString();
	               message=jObj.get("message").toString();
	                try{
	                  JSONArray array=(JSONArray)jObj.get("datas");
	                  if(array==null)
	                  {
	                     
	                     // null ó��
	                     return;
	                  }
	                  team_id=new ArrayList<String>();
	                 team_name=new ArrayList<String>();
	                  for(int i=0;i<array.size();i++){
	                     JSONObject teamJsonObj= (JSONObject)jsonParser.parse(array.get(i).toString());
	                     
	                     if(teamJsonObj==null)
	                        continue;
	                     try{
	                     
	                        team_id.add(teamJsonObj.get("team_id").toString());
	                        
	                        team_name.add(teamJsonObj.get("team_name").toString());
	                        
	                     }
	                     
	                      catch(Exception ex){
	                           Toast.makeText(context, ex.getMessage(), Toast.LENGTH_LONG);
	                           }
	                     
	                     
	                  
	                  }
	               }
	               catch(Exception ex){
	               Toast.makeText(context, ex.getMessage(), Toast.LENGTH_LONG);
	               }
	           } catch (Exception ex) {

	           }

	      }
	     



private void plusSosoParsing(String info) {
	   JSONParser jsonParser = new JSONParser();
       try {
           JSONObject jObj = (JSONObject)jsonParser.parse(info);
           result=jObj.get("result").toString();
           message=jObj.get("message").toString();
         
       } catch (Exception ex) {

       }
	
}

private void plusLikeParsing(String info) {
	      
	      JSONParser jsonParser = new JSONParser();
	        try {
	            JSONObject jObj = (JSONObject)jsonParser.parse(info);
	            result=jObj.get("result").toString();
	            message=jObj.get("message").toString();
	          
	        } catch (Exception ex) {

	        }
	
}

private void getTeamTimeTableParsing(String info) {
	  JSONParser jsonParser = new JSONParser();
      try {
           JSONObject jObj = (JSONObject)jsonParser.parse(info);
            result=jObj.get("result").toString();
            message=jObj.get("message").toString();
             try{
               JSONArray array=(JSONArray)jObj.get("datas");
               if(array==null)
               {
                  
                  // null ó��
                  return;
               }
               team_id=new ArrayList<String>();
              team_name=new ArrayList<String>();
               for(int i=0;i<array.size();i++){
                  JSONObject teamJsonObj= (JSONObject)jsonParser.parse(array.get(i).toString());
                  
                  if(teamJsonObj==null)
                     continue;
                  try{
                  
                     team_id.add(teamJsonObj.get("team_id").toString());
                     
                     team_name.add(teamJsonObj.get("team_name").toString());
                     
                  }
                  
                   catch(Exception ex){
                        Toast.makeText(context, ex.getMessage(), Toast.LENGTH_LONG);
                        }
                  
                  
               
               }
            }
            catch(Exception ex){
            Toast.makeText(context, ex.getMessage(), Toast.LENGTH_LONG);
            }
        } catch (Exception ex) {

        }
   }

   private void delTimeTableParsing(String info) {
      
      JSONParser jsonParser = new JSONParser();
        try {
            JSONObject jObj = (JSONObject)jsonParser.parse(info);
            result=jObj.get("result").toString();
            message=jObj.get("message").toString();
          
        } catch (Exception ex) {

        }
   }

   private void addTimeTableParsing(String info) {
      
      JSONParser jsonParser = new JSONParser();
        try {
            JSONObject jObj = (JSONObject)jsonParser.parse(info);
            result=jObj.get("result").toString();
            message=jObj.get("message").toString();
          
        } catch (Exception ex) {

        }
   }

   private void deleteNodeParsing(String info) {
      JSONParser jsonParser = new JSONParser();
        try {
            JSONObject jObj = (JSONObject)jsonParser.parse(info);
            result=jObj.get("result").toString();
            message=jObj.get("message").toString();
          
        } catch (Exception ex) {

        }
      
      
   }

   public void loginParsing(String info){
 
      try{
         JSONParser jsonParser = new JSONParser();
           try {
               JSONObject jObj = (JSONObject)jsonParser.parse(info);
               result=jObj.get("result").toString();
               message=jObj.get("message").toString();
               token=jObj.get("token").toString();
               userId=jObj.get("id").toString();
           } catch (Exception ex) {

           }

      }
        catch ( Exception e ) {
            e.printStackTrace();
        }    
            

   }
   
   public void createTeamParsing(String info){
       
      try{
         JSONParser jsonParser = new JSONParser();
           try {
              JSONObject jObj = (JSONObject)jsonParser.parse(info);
               result=jObj.get("result").toString();
               message=jObj.get("message").toString();
               
            
               
               
               
           
           } catch (Exception ex) {

           }

      }
        catch ( Exception e ) {
            e.printStackTrace();
        }    
            

   }
   public void teamListParsing(String info){
       
      try{

         JSONParser jsonParser = new JSONParser();
      
           try {
              JSONObject jObj = (JSONObject)jsonParser.parse(info);
               result=jObj.get("result").toString();
               message=jObj.get("message").toString();
              

               try{
                  JSONArray array=(JSONArray)jObj.get("datas");
                  if(array==null)
                  {
                     
                     // null ó��
                     return;
                  }
                  team_id=new ArrayList<String>();
                 team_name=new ArrayList<String>();
                  for(int i=0;i<array.size();i++){
                     JSONObject teamJsonObj= (JSONObject)jsonParser.parse(array.get(i).toString());
                     
                     if(teamJsonObj==null)
                        continue;
                     try{
                     
                        team_id.add(teamJsonObj.get("team_id").toString());
                        
                        team_name.add(teamJsonObj.get("team_name").toString());
                        
                     }
                     
                      catch(Exception ex){
                           Toast.makeText(context, ex.getMessage(), Toast.LENGTH_LONG);
                           }
                     
                     
                    //saveData.setTeam(obj.get("team_id").toString(),obj.get("team_name").toString());
                  }
               }
               catch(Exception ex){
               Toast.makeText(context, ex.getMessage(), Toast.LENGTH_LONG);
               }
           } catch (Exception ex) {

           }

      }
        catch ( Exception e ) {
            e.printStackTrace();
        }    
            

   }
   
   public void memberListParsing(String info){
       
      try{

         JSONParser jsonParser = new JSONParser();
      
           try {
              JSONObject jObj = (JSONObject)jsonParser.parse(info);
               result=jObj.get("result").toString();
               message=jObj.get("message").toString();
              

               try{
                  JSONArray array=(JSONArray)jObj.get("datas");
                  if(array==null)
                  {
                     
                     // null ó��
                     return;
                  }
                  user_id=new ArrayList<String>();
                 user_number=new ArrayList<String>();
                  for(int i=0;i<array.size();i++){
                     JSONObject teamJsonObj= (JSONObject)jsonParser.parse(array.get(i).toString());
                     
                     if(teamJsonObj==null)
                        continue;
                     try{
                     
                        user_id.add(teamJsonObj.get("user_id").toString());
                        
                        user_number.add(teamJsonObj.get("user_number").toString());
                        
                     }
                     
                      catch(Exception ex){
                           Toast.makeText(context, ex.getMessage(), Toast.LENGTH_LONG);
                           }
                     
                     
                 
                  }
               }
               catch(Exception ex){
               Toast.makeText(context, ex.getMessage(), Toast.LENGTH_LONG);
               }
           } catch (Exception ex) {

           }

      }
        catch ( Exception e ) {
            e.printStackTrace();
        }    
            

   }
   public void teamSignUpParsing(String info){
       
      try{
         JSONParser jsonParser = new JSONParser();
           try {
              JSONObject jObj = (JSONObject)jsonParser.parse(info);
               result=jObj.get("result").toString();
               message=jObj.get("message").toString();
               
           } catch (Exception ex) {

           }

      }
        catch ( Exception e ) {
            e.printStackTrace();
        }    
            

   }
   public void getNodeParsing(String info){
       
      try{
         JSONParser jsonParser = new JSONParser();
           try {
              JSONObject jObj = (JSONObject)jsonParser.parse(info);
               result=jObj.get("result").toString();
               message=jObj.get("message").toString();
               
               JSONArray array=(JSONArray)jObj.get("datas");
               if(array==null)
                  return;
               
               
               textData=new ArrayList<List<String>>();
               nodeId=new ArrayList<List<String>>();
               time=new ArrayList<List<String>>();
               writeUser=new ArrayList<List<String>>();
               int temp=0;
               int count=0;
               for(int i=0;i<array.size();i=count){
                  
                   List<String> child_index=new ArrayList<String>();
                   List<String> node_id=new ArrayList<String>();
                   List<String> node_writer=new ArrayList<String>();
                   List<String> node_time=new ArrayList<String>();
                   for(int j=count;j<array.size();j++){
                        JSONObject nodeJsonObj= (JSONObject)jsonParser.parse(array.get(j).toString());
                         if(temp<Integer.parseInt(nodeJsonObj.get("main_index").toString())){
                            temp=Integer.parseInt(nodeJsonObj.get("main_index").toString());
                            
                            break;
                         }
                         child_index.add(nodeJsonObj.get("textData").toString());
                         node_id.add(nodeJsonObj.get("node_id").toString());
                         node_time.add(nodeJsonObj.get("updated_at").toString());
                         node_writer.add(nodeJsonObj.get("user_idNumber").toString());
                         
                         count++;
                      }
                      textData.add(child_index);
                      nodeId.add(node_id);
                      writeUser.add(node_writer);
                      time.add(node_time);
                     
                  }
                  
                  
               
           } catch (Exception ex) {

              ex.getMessage();
           }

      }
        catch ( Exception e ) {
            e.printStackTrace();
        }    
            

   }
   public void mainNodeParsing(String info){
       
      try{
         JSONParser jsonParser = new JSONParser();
           try {
              JSONObject jObj = (JSONObject)jsonParser.parse(info);
               result=jObj.get("result").toString();
               message=jObj.get("message").toString();
               
           } catch (Exception ex) {

           }

      }
       catch ( Exception e ) {
               e.printStackTrace();
           }    
   }
      public void childNodeParsing(String info){
          
         try{
            JSONParser jsonParser = new JSONParser();
              try {
                 JSONObject jObj = (JSONObject)jsonParser.parse(info);
                  result=jObj.get("result").toString();
                  message=jObj.get("message").toString();
                  
              } catch (Exception ex) {

              }

         }
           catch ( Exception e ) {
               e.printStackTrace();
           }    
               

      }
       
        
            

   
   
   
   public String returnResult(){
      return result;
   }
   
   public String returnMessage(){
      return message;
   }
   public String returnToken(){
      return token;
   }
   public String returnId(){
      return userId;
   }
   public List<String> returnteamName(){
   return team_name;
   }
   public List<String> returnteamId(){
      return team_id;
   }
   public List<String> returnuserId(){
      return user_id;
   }
   public List<String> returnuserNumber(){
      return user_number;
   }
   public List<List<String>> returntextData(){
      return textData;
   }
   public List<List<String>> returnnodeId(){
      return nodeId;
   }
   public List<List<String>> returnWriteUser(){
      return writeUser;
   }
   public List<List<String>> returnTime(){
      return time;
   }
}