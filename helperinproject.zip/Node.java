package com.example.helperinproject;


import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;


public class Node extends View
{
	private int depth;
	public List<Node> nodeList;
	public List<String> commentList;
	private LinearLayout.LayoutParams nodeParams;
	final int CIRCLE_WIDTH=150;
	final int CIRCLE_HEIGHT=150;
	private String nodeNum;
	private String time;
	private String user;
	private int color;
	private int alpha;
	
public Node(Context context) {
		super(context);
		depth=0;
		nodeList=new ArrayList<Node>();
		commentList=new ArrayList<String>();
		nodeParams=new LinearLayout.LayoutParams(CIRCLE_WIDTH, CIRCLE_HEIGHT);
		this.setLayoutParams(nodeParams);
		color=0x66cdaa;
		alpha=100;
}

public Node(Context context,Node node) {
	super(context);
	depth=node.depth;
	nodeList=new ArrayList<Node>();
	commentList=new ArrayList<String>();
	nodeParams=new LinearLayout.LayoutParams(CIRCLE_WIDTH, CIRCLE_HEIGHT);
	this.setLayoutParams(nodeParams);
	color=0x66cdaa;
	alpha=100;
}

public int getDepth(){
	return depth;
}
public void setDepth(int i){
	depth=i;
}
public void setUser(String i){
	user=i;
}
public String getUser(){
	return user;
}
public void setTime(String i){
	time=i;
}
public String getTime(){
	return time;
}
public void setNum(String i){
	nodeNum=i;
}
public String getNum(){
	return nodeNum;
}
public void setColor(int i){
	color=i;
}
public void setAlpha(int i){
	alpha=i;
}





public void onDraw(Canvas canvas){
	//canvas.drawColor(Color.WHITE);
	 Paint pnt=new Paint();
	 pnt.setColor(color);
	 pnt.setAlpha(alpha);
	 canvas.drawCircle(70,70, 70, pnt);
	 
	 
	 
}







}
