package com.example.helperinproject;

public  class saveData {

	private static String team_id;
	private static int team_index;
	private static String userNum;
	private static String token;
	public static void setTeam_id(String s){
		team_id=s;
	}
	public static String getTeam_id(){
		return team_id;
	}
	
	public static void setTeam_index(int i){
		team_index=i;
	}
	public static int getTeam_index(){
		return team_index;
	}
	public static void setUserNum(String s){
		userNum=s;
	}
	public static String getUserNum(){
		return userNum;
	}
	public static void setToken(String s){
		token=s;
	}
	public static String getToken(){
		return token;
	}
	
}
