package com.example.helperinproject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class HIP_Signup extends Activity {

	ArrayList<String> listItem; // ����Ʈ�� ������ ����
	ArrayAdapter<String> Adapter;// �����
	private ListView list; // ����Ʈ��
	ArrayAdapter<CharSequence> spinner1_adapter; // ���ǳ� for day of the week
	ArrayAdapter<CharSequence> spinner2_adapter; // ���ǳ� time
	ArrayAdapter<CharSequence> spinner3_adapter;
	List<Map<String, String>> scedule;
	Spinner spinner1;
	Spinner spinner2;
	Spinner spinner2_1;
	Spinner spinner3;
	Spinner spinner3_1;
	boolean[][] mtxSchedule;
	List<List<Integer>> mtxNum;
	List<Integer> days;
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE); // �� ����
		setContentView(R.layout.activity_hip__signup);

		listItem = new ArrayList<String>();// ������ ������ ���� ����Ʈ ����
		Adapter = new ArrayAdapter<String>(this, R.layout.introlistcolor, listItem); // adapter
		
		mtxNum=new ArrayList<List<Integer>>();
		days=new ArrayList<Integer>();
		LinearLayout li = (LinearLayout) findViewById(R.id.visible);
		//li.setVisibility(li.INVISIBLE);
		list = (ListView) findViewById(R.id.list);
		list.setAdapter(Adapter);// adapter ����
		list.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE); // list ���ø�� ����
		scedule = new ArrayList<Map<String, String>>();
		// ���ǳ� ����
		spinner1 = (Spinner) findViewById(R.id.spinner_day);
		spinner2 = (Spinner) findViewById(R.id.spinner_hour);
		spinner2_1 = (Spinner) findViewById(R.id.spinner_minute);
		spinner3 = (Spinner) findViewById(R.id.spinner_hour2);
		spinner3_1 = (Spinner) findViewById(R.id.spinner_minute2);
		
		spinner1.setPrompt("���� ����");
		spinner2.setPrompt("���� �ð�");
		spinner2_1.setPrompt("���� ��");
		spinner3.setPrompt("���� �ð�");
		spinner3_1.setPrompt("���� ��");

		spinner1_adapter = ArrayAdapter.createFromResource(this, R.array.day_of_the_week, R.layout.spinnercolor);
		spinner2_adapter = ArrayAdapter.createFromResource(this, R.array.array_time, R.layout.spinnercolor);
		spinner3_adapter = ArrayAdapter.createFromResource(this, R.array.array_minute, R.layout.spinnercolor);
		spinner1.setAdapter(spinner1_adapter);
		spinner2.setAdapter(spinner2_adapter);
		spinner2_1.setAdapter(spinner3_adapter);
		spinner3.setAdapter(spinner2_adapter);
		spinner3_1.setAdapter(spinner3_adapter);
		setmtx();

	}

	class MyItem {
		CharSequence day;
		CharSequence time;

		MyItem(CharSequence d, CharSequence t) {
			day = d;
			time = t;
		}
	}

	public void introClickListener(View v) {
		switch (v.getId()) {
		case R.id.add:
			TextView classname = (TextView) findViewById(R.id.classname);
			if (classname.getText().toString().length() == 0) {

				Toast.makeText(HIP_Signup.this, "������� �Է��ϼ���!", Toast.LENGTH_LONG).show();
			} else {
				String selDate = spinner1_adapter.getItem(spinner1.getSelectedItemPosition()).toString();
				String selStHour = spinner2_adapter.getItem(spinner2.getSelectedItemPosition()).toString();
				String selStMin = spinner3_adapter.getItem(spinner2_1.getSelectedItemPosition()).toString();
				String selEndHour = spinner2_adapter.getItem(spinner3.getSelectedItemPosition()).toString();
				String selEndMin = spinner3_adapter.getItem(spinner3_1.getSelectedItemPosition()).toString();
				String classTime = selStHour + ":" + selStMin + "~" + selEndHour + ":" + selEndMin;

				if (addschedule(selDate, selStHour, selStMin, selEndHour, selEndMin)) {
					
					
					// dayCalculator(selDate);
					//
					int day = dayCalculator(selDate);
					 days.add(day);
					List<Integer> classlist=new ArrayList<Integer>();
						int timeIndex=Integer.parseInt(selStHour)-9;
						int controlNum=0;
						if(selStMin.equals("30"))
						 controlNum=1;
					
							if (day < 0 || timeIndex < 0) {
								// ����ó��
								return;
							}
							int roop=2*timeIndex+controlNum;
							while(true){
							
							if(mtxSchedule[roop][day]){
								classlist.add(roop);
								
							}
							else
								break;
						
							roop++;
						}
							mtxNum.add(classlist);
						
						if(classlist.size()<=0)
							return;
						for(int i=0;i<classlist.size();i++){
						StringBuilder urlBuilder = new StringBuilder("http://sejong.yarr.kr/index.php/api/add_time_table?");
						urlBuilder.append(String.format("user_number=%s",saveData.getUserNum() ));
						urlBuilder.append(String.format("&token=%s", saveData.getToken()));
						urlBuilder.append(String.format("&day=%d", day));
						urlBuilder.append(String.format("&time_index=%s", classlist.get(i)));
						urlBuilder.append(String.format("&class_name=%s", classname.getText()));

						Comunication intro = new Comunication(v.getContext(), urlBuilder.toString(), "addtimetable");

						if (intro.returnResult().equals("1")) {
							if(i==(classlist.size()-1)){
								listItem.add(selDate + "/" + classname.getText().toString() + '\n' + classTime);
								Adapter.notifyDataSetChanged();
								Toast.makeText(v.getContext(), classname.getText(), Toast.LENGTH_SHORT).show();
								}

						} else if (intro.returnResult().equals("0")) {
							Toast.makeText(v.getContext(), intro.returnMessage(), Toast.LENGTH_SHORT).show();
						}
					
						}
				}
					 else {
						Toast.makeText(HIP_Signup.this, "�Է� ����!(���ǽð�Ȯ��)", Toast.LENGTH_LONG).show();
					}
					
						classname.setText("");
			}
				
			break;
		case R.id.delete:
			
			SparseBooleanArray checkedItems = list.getCheckedItemPositions();
			if (checkedItems.size() != 0) {
				
				
				for (int index = list.getCount() - 1; index >= 0; index--) {
					if (checkedItems.get(index)){
						int con=mtxNum.get(index).size();
						for(int x=0;x<con;x++){
						StringBuilder urlBuilder = new StringBuilder("http://sejong.yarr.kr/index.php/api/del_time_table?");
						urlBuilder.append(String.format("user_number=%s",saveData.getUserNum() ));
						urlBuilder.append(String.format("&token=%s", saveData.getToken()));
						urlBuilder.append(String.format("&day=%d",days.get(index)));
						urlBuilder.append(String.format("&time_index=%s", mtxNum.get(index).get(x)));
						

						Comunication intro = new Comunication(v.getContext(), urlBuilder.toString(), "deltimetable");

						if (intro.returnResult().equals("1")) {
						
							if(x==(mtxNum.get(index).size()-1)){
							listItem.remove(index);
							days.remove(index);
							mtxNum.remove(index);
							Toast.makeText(v.getContext(), intro.returnMessage(), Toast.LENGTH_SHORT).show();
							}
						} else if (intro.returnResult().equals("0")) {
							Toast.makeText(v.getContext(), intro.returnMessage(), Toast.LENGTH_SHORT).show();
							
						}
					}
					}
				list.clearChoices();
				Adapter.notifyDataSetChanged();
				}
			} else {
				Toast.makeText(HIP_Signup.this, R.string.input_no_checked, Toast.LENGTH_SHORT).show();
				
			}

			break;
		case R.id.introfinish:
			this.finish();
			break;

		case R.id.Intro:
			EditText ID = (EditText) findViewById(R.id.IDInput);
			EditText passwd = (EditText) findViewById(R.id.passwordInput);
			EditText repasswd = (EditText) findViewById(R.id.repasswordInput);
			String pswd = passwd.getText().toString();
			String repswd = repasswd.getText().toString();
			String strID = ID.getText().toString();

			if (strID.length() == 0) {
				Toast.makeText(HIP_Signup.this, "ID�Է� Ȯ��", Toast.LENGTH_SHORT).show();
			} else {
				if (pswd.equals(repswd) && (pswd.length() >= 8)) {

					TextView id = (TextView) findViewById(R.id.IDInput);
					TextView pw = (TextView) findViewById(R.id.passwordInput);
					String url = "http://sejong.yarr.kr/index.php/api/signUp/" + id.getText().toString() + "/"
							+ pw.getText().toString();

					Comunication intro = new Comunication(v.getContext(), url, "login");

					if (intro.returnResult().equals("1")) {
						LinearLayout li = (LinearLayout) findViewById(R.id.visible);
						li.setVisibility(li.VISIBLE);
						LinearLayout li2 = (LinearLayout) findViewById(R.id.uservisible);
						//li2.setVisibility(li.INVISIBLE);
						li2.findViewById(R.id.IDInput).setFocusable(false);
						li2.findViewById(R.id.alias).setFocusable(false);
						li2.findViewById(R.id.passwordInput).setFocusable(false);
						li2.findViewById(R.id.repasswordInput).setFocusable(false);
						li2.findViewById(R.id.Intro).setClickable(false);
					
						
						
						TextView tv = (TextView) findViewById(R.id.introtext);
						tv.setText("�߰�����");
						String url2 = "http://sejong.yarr.kr/index.php/api/login/" + id.getText().toString() + "/"
								+ pw.getText().toString();
						Comunication intro2 = new Comunication(v.getContext(), url2, "login");
						saveData.setUserNum(intro2.returnId());
						saveData.setToken(intro2.returnToken());
						Toast.makeText(HIP_Signup.this, intro.returnMessage(), Toast.LENGTH_SHORT).show();

					} else if (intro.returnResult().equals("0"))
						Toast.makeText(HIP_Signup.this, intro.returnMessage(), Toast.LENGTH_SHORT).show();
				} else {
					if (pswd.length() < 8) {
						passwd.setText("");
						repasswd.setText("");
						Toast.makeText(HIP_Signup.this, "��й�ȣ 8�� �̻� �Է�", Toast.LENGTH_SHORT).show();
					} else {
						passwd.setText("");
						repasswd.setText("");
						Toast.makeText(HIP_Signup.this, "��й�ȣ �Է� Ȯ��", Toast.LENGTH_SHORT).show();
					}

				}
			}

			break;
					}
	}
				
		

			
	
	
		
	public int dayCalculator(String date) {
		int dateindex = -1;
		if (date.equals("������"))
			dateindex = 0;
		else if (date.equals("ȭ����"))
			dateindex = 1;
		else if (date.equals("������"))
			dateindex = 2;
		else if (date.equals("�����"))
			dateindex = 3;
		else if (date.equals("�ݿ���"))
			dateindex = 4;
		else if (date.equals("�����"))
			dateindex = 5;
		else if (date.equals("�Ͽ���"))
			dateindex = 6;
		return dateindex;
	}

	public boolean addschedule(String date, String sthour, String stmin, String endhour, String endmin) {
		int dateindex = 0;
		int stTimeIndex = 0;
		int endTimeIndex = 0;
		if (date.equals("������"))
			dateindex = 0;
		else if (date.equals("ȭ����"))
			dateindex = 1;
		else if (date.equals("������"))
			dateindex = 2;
		else if (date.equals("�����"))
			dateindex = 3;
		else if (date.equals("�ݿ���"))
			dateindex = 4;
		else if (date.equals("�����"))
			dateindex = 5;
		else if (date.equals("�Ͽ���"))
			dateindex = 6;

		stTimeIndex = gettimeindex(sthour, stmin);
		endTimeIndex = gettimeindex(endhour, endmin);
		if (stTimeIndex >= endTimeIndex)
			return false;
		for (int i = stTimeIndex; i < endTimeIndex; i++) {
			if (mtxSchedule[i][dateindex] == true) {
				return false;
			}
		}
		for (int i = stTimeIndex; i < endTimeIndex; i++) {
			mtxSchedule[i][dateindex] = true;
		}
		return true;
	}

	public void setmtx() {
		mtxSchedule = new boolean[18][7];
	}

	public int gettimeindex(String Hour, String Min) {
		int index = 0;
		switch (Integer.parseInt(Hour)) {
		case 9:
			index = 0;
			break;
		case 10:
			index = 2;
			break;
		case 11:
			index = 4;
			break;
		case 12:
			index = 6;
			break;
		case 13:
			index = 8;
			break;
		case 14:
			index = 10;
			break;
		case 15:
			index = 12;
			break;
		case 16:
			index = 14;
			break;
		case 17:
			index = 16;
			break;
		}
		switch (Integer.parseInt(Min)) {
		case 0:
			break;
		case 30:
			index++;
			break;
		}
		return index;
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.hip__signup, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}