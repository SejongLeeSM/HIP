package com.example.helperinproject;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.Legend.LegendPosition;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.formatter.PercentFormatter;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.listener.OnChartValueSelectedListener;
import com.github.mikephil.charting.utils.ColorTemplate;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.TabActivity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Entity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.ColorDrawable;
import android.media.ImageReader;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout.LayoutParams;
import android.util.DisplayMetrics;
import android.util.SparseBooleanArray;
import android.util.TypedValue;
import android.view.*;

import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.ScaleAnimation;
import android.view.animation.TranslateAnimation;
import android.widget.*;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.TabHost.OnTabChangeListener;
import android.widget.TabHost.TabSpec;

public class HIP_Manager extends TabActivity implements OnTabChangeListener{
	//
	//

	LinearLayout.LayoutParams textParams;
	TabHost mTab;
	Node firstNode;
	TextView firstText;
	List<List<String>> comunicationNode;
	List<List<String>> comunicationNodeId;
	List<List<String>> comunicationuser;
	List<List<String>> comunicationtime;
	RelativeLayout lay;
	ArrayAdapter<String> summary_Adapter;
	ListView toDoList;
	Spinner summaryspin;
	ArrayAdapter<String> spinner_adapter;
	String node_id;
	String deadTime;
	LinearLayout rate;
	private float[] yData={5,10,15,30,40};
	private String[] xData={"�̴���","������","������","�̼���","�迵��"};
	PieChart chart;
	private float mx, my;
	private float curX, curY;

	private ScrollView vScroll;
    private HorizontalScrollView hScroll;

	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);   //�� ����
		
		 

		mTab=getTabHost();
		mTab.setOnTabChangedListener(this);
		LayoutInflater inflater=LayoutInflater.from(this);
		try{
		inflater.inflate(R.layout.activity_hip__manger, mTab.getTabContentView(),true);
		}
		catch(Exception e){

			
			e.printStackTrace();
		}
		mTab.addTab(mTab.newTabSpec("tag")
				.setIndicator("Doing",getResources().getDrawable(R.drawable.doing))
				.setContent(R.id.project_process));
		mTab.addTab(mTab.newTabSpec("tag")
				.setIndicator("To Do",getResources().getDrawable(R.drawable.todo))
				.setContent(R.id.project_summary));
		
		mTab.addTab(mTab.newTabSpec("tag")
				.setIndicator("Rate",getResources().getDrawable(R.drawable.rate))
				.setContent(R.id.project_rate));
	textParams=new LinearLayout.LayoutParams(250,LayoutParams.WRAP_CONTENT); 
		//vScroll = (ScrollView) findViewById(R.id.vScroll);
		//hScroll = (HorizontalScrollView) findViewById(R.id.hScroll);
		//for(int i =0; i<mTab.getTabWidget().getChildCount();i++)
		//{
			mTab.getTabWidget().getChildAt(mTab.getCurrentTab()).setBackgroundColor(R.drawable.green_color);
		//}
		

		firstNode=new Node(this);
		spinner_adapter=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,firstNode.commentList);
		summaryspin=(Spinner)findViewById(R.id.commentspin);
		summaryspin.setPrompt("node");
		summaryspin.setAdapter(spinner_adapter);
		
		
		DisplayMetrics dm = getApplicationContext().getResources().getDisplayMetrics();
		int width = dm.widthPixels;

		firstNode.setX(width/2);
		firstNode.setY(STARTY);
		lay=(RelativeLayout)findViewById(R.id.tree);
		LocateCircleAndText(firstNode,saveData.getTeam_id());
		initListView();
		
		SharedPreferences prefs=getSharedPreferences("user",Activity.MODE_PRIVATE);
	  	
		String url="http://sejong.yarr.kr/index.php/api/get_nodes/"+prefs.getString("userNum","")
		+"/"+prefs.getString("token","")+"/"+saveData.getTeam_id();
		Comunication getnode=new Comunication(HIP_Manager.this,url,"getnode");
		if(getnode.returnResult().equals("1")){
		Toast.makeText(HIP_Manager.this,getnode.returnMessage(), Toast.LENGTH_SHORT).show();
		
		}
		else if(getnode.returnResult().equals("0"))
			Toast.makeText(HIP_Manager.this,getnode.returnMessage(), Toast.LENGTH_SHORT).show();
		comunicationNode=getnode.returntextData();
		comunicationNodeId=getnode.returnnodeId();
		comunicationuser=getnode.returnWriteUser();
		comunicationtime=getnode.returnTime();
		if(comunicationNode==null)
			return;
		
		if(comunicationNode!=null||comunicationNode.size()!=0){
			
			for(int i=0;i<comunicationNode.size();i++){
				List<String> tempList=comunicationNode.get(i);
				List<String> tempList2=comunicationNodeId.get(i);
				List<String> tempList3=comunicationuser.get(i);
				List<String> tempList4=comunicationtime.get(i);
				Node n=null;
				try{
				n=LocateSummaryNode(tempList.get(0),Integer.parseInt(tempList2.get(0)));
				}
				catch(Exception e){
					e.printStackTrace();
				}
				n.setTime(tempList4.get(0));
				n.setUser(tempList3.get(0));
			}
			
	
		 		for(int i=0;i<comunicationNode.size();i++){
					List<String> tempList=comunicationNode.get(i);
					List<String> tempList2=comunicationNodeId.get(i);
					List<String> tempList3=comunicationuser.get(i);
					List<String> tempList4=comunicationtime.get(i);
					if(tempList==null)
					{
						continue;
					}
					for(int j=1;j<=tempList.size()-1;j++){
						
						Node n=addSubTree(tempList.get(j),i,Integer.parseInt(tempList2.get(j)));
						n.setTime(tempList4.get(j));
						n.setUser(tempList3.get(j));
					}
				
			
			
		}
		summary_Adapter.notifyDataSetChanged();
		spinner_adapter.notifyDataSetChanged();
	}
	 rate=(LinearLayout)findViewById(R.id.project_rate);
	}
	final int PADDING=150;
	final int STARTX=100;
	final int STARTY=100;
	final int DEPTH=380;
	private void LocateCircleAndText(Node n,String s){
		lay.addView(n);
		TextView tv=new TextView(this);
		tv.setLayoutParams(textParams);
		tv.setText(s);
		tv.setX(n.getX());
		tv.setY(n.getY()+PADDING);
		lay.addView(tv);
		setAnimation(tv);
		setAnimation(n);
	}

	private int userNodeCount(String userName){
		int count=0;
		for(int i=0;i<comunicationuser.size();i++){
		List<String> temp=comunicationuser.get(i);
		for(int j=0;j<temp.size();j++){
			if(userName.equals(temp.get(j)))
					count++;
		}
		
		}
		return count;
	}
	private int totalNodeCount(){
		int count=0;
		for(int i=0;i<comunicationuser.size();i++){
		List<String> temp=comunicationuser.get(i);
		for(int j=0;j<temp.size();j++){
					count++;
		}
		
		}
		return count;
	}
	

	private void initListView(){
		summary_Adapter=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_single_choice,firstNode.commentList);  //����� �غ�
		toDoList=(ListView)findViewById(R.id.sumarylist);  
		toDoList.setAdapter(summary_Adapter);//����� ����
		toDoList.setChoiceMode(ListView.CHOICE_MODE_SINGLE);   // ���ø�� ���� (�Ѱ���)
		toDoList.setDivider(new ColorDrawable(Color.LTGRAY)); //���м� ���� ����
		toDoList.setDividerHeight(3);   //���м� ���� ����
		summary_Adapter.notifyDataSetChanged();
		
	}

	private void setAnimation(View iv){
		Animation ani=new ScaleAnimation(0,1,0,1);
		ani.setFillAfter(true);
		ani.setDuration(550);
		iv.setAnimation(ani);
	}
	



	
	private Node LocateSummaryNode(String tv,int control){
		
		
		if(tv.length()!=0)
		{
			if(tv.length()<=12){
			
		Node summaryNode=new Node(this);
		
		firstNode.nodeList.add(summaryNode);
		setDepthforArrange(summaryNode);
		firstNode.commentList.add(tv);
	    SharedPreferences prefs=getSharedPreferences("user",Activity.MODE_PRIVATE);
	    Calendar calendar=Calendar.getInstance();
	    SimpleDateFormat datefomat=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		summaryNode.setTime(datefomat.format(calendar.getTime()));   
	    summaryNode.setUser(prefs.getString("userNum", ""));
		if(control==0){
		String urlbuilder="http://sejong.yarr.kr/index.php/api/add_main_node?user_number="+prefs.getString("userNum","")
		+"&token="+prefs.getString("token","")+"&team_id="+saveData.getTeam_id()+"&text_data="+tv;
		Comunication score=new Comunication(HIP_Manager.this,urlbuilder,"mainnode");
		if(score.returnResult().equals("1")){
		Toast.makeText(HIP_Manager.this,score.returnMessage(), Toast.LENGTH_SHORT).show();
		
		}
		else if(score.returnResult().equals("0"))
		Toast.makeText(HIP_Manager.this,score.returnMessage(), Toast.LENGTH_SHORT).show();
    	}
    	
    	
    	summaryNode.setTag(control);
    	
    	
		summaryNode.setX(summaryNode.getDepth()*DEPTH+STARTX);
		summaryNode.setY(firstNode.getY()+DEPTH);
		LocateCircleAndText(summaryNode,tv);
		DrawLine line=new DrawLine(this,firstNode,summaryNode);
		lay.addView(line);
		setAnimation(line);
		return summaryNode;
		}
			else if(tv.length()>12)
				Toast.makeText(this, "12���̳��� �Է�", Toast.LENGTH_SHORT).show();
		return null;
		}
		else if(tv.length()==0)
		Toast.makeText(this, "�Է³����� �����ϴ�", Toast.LENGTH_SHORT).show();
		
		return null;
	}
	private void arrangeSummary(int doneindex){
		for(int i=0;i<firstNode.nodeList.size();i++){
			setDepthforArrange(firstNode.nodeList.get(i));	
		firstNode.nodeList.get(i).setX(firstNode.nodeList.get(i).getDepth()*DEPTH+STARTX);
		firstNode.nodeList.get(i).setY(firstNode.getY()+DEPTH);
		if(doneindex==i){
		firstNode.nodeList.get(i).setColor(0x1e90ff);
		firstNode.nodeList.get(i).setAlpha(200);
		}
		LocateCircleAndText(firstNode.nodeList.get(i),firstNode.commentList.get(i));
		DrawLine line=new DrawLine(this,firstNode,firstNode.nodeList.get(i));
		lay.addView(line);
		setAnimation(line);
		for(int j=0;j<firstNode.nodeList.get(i).nodeList.size();j++)
		{
			firstNode.nodeList.get(i).nodeList.get(j).setX(firstNode.nodeList.get(i).getX());
			firstNode.nodeList.get(i).nodeList.get(j).setY(firstNode.nodeList.get(i).getY()+DEPTH*(j+1));
			if(doneindex==i){
				firstNode.nodeList.get(i).nodeList.get(j).setColor(0x1e90ff);
				firstNode.nodeList.get(i).nodeList.get(j).setAlpha(200);
			}
			LocateCircleAndText(firstNode.nodeList.get(i).nodeList.get(j),
					firstNode.nodeList.get(i).commentList.get(j));
		}
		for(int k=0;k<firstNode.nodeList.get(i).nodeList.size();k++)
		drawLineAtSub(firstNode.nodeList.get(i));
		}	
		}
		
	private void setDepthforArrange(Node n){
	n.setDepth(firstNode.nodeList.indexOf(n));
		
	}
	
	

	public void buttonListener(View v){
		switch(v.getId()){
		case R.id.rateoutput:
			SharedPreferences pref=getSharedPreferences("user",Activity.MODE_PRIVATE);
			StringBuilder urlBuilder = new StringBuilder("http://sejong.yarr.kr/index.php/api/get_team_score?");
			urlBuilder.append(String.format("user_number=%s",pref.getString("userNum","")));
			urlBuilder.append(String.format("&token=%s", pref.getString("token","")));
			urlBuilder.append(String.format("&team_id=%s",saveData.getTeam_id()));
			Comunication scrore=new Comunication(HIP_Manager.this,urlBuilder.toString(),"getscore");
			if(scrore.returnResult().equals("1")){
			Toast.makeText(HIP_Manager.this,scrore.returnMessage(), Toast.LENGTH_SHORT).show();
			}
			else if(scrore.returnResult().equals("0"))
			Toast.makeText(HIP_Manager.this,scrore.returnMessage(), Toast.LENGTH_SHORT).show();
			
			Button b=(Button)findViewById(R.id.rateoutput);
			b.setVisibility(b.INVISIBLE);
			chart = (PieChart) findViewById(R.id.chart);
			chart.setUsePercentValues(true);
			chart.setDescription("������ �⿩�� ��");
			chart.setDrawHoleEnabled(true);
			chart.setHoleColorTransparent(true);
			chart.setHoleRadius(7);
			chart.setTransparentCircleRadius(10);
			chart.setRotationAngle(0);
			chart.setRotationEnabled(true);
			chart.setOnChartValueSelectedListener(new OnChartValueSelectedListener() {
				
				@Override
				public void onValueSelected(Entry e, int dataSetIndex, Highlight h) {
					
					if(e==null)
					return;
					
					Toast.makeText(HIP_Manager.this, 
							xData[e.getXIndex()]+" = "+e.getVal()+"%", 
							Toast.LENGTH_SHORT).show();
				}
				
				@Override
				public void onNothingSelected() {
					// TODO Auto-generated method stub
					
				}
			});
	        addData();
	        Legend l=chart.getLegend();
	        l.setPosition(LegendPosition.RIGHT_OF_CHART);
	        l.setXEntrySpace(7);
	        l.setYEntrySpace(5);
	        
	
			
			
		break;
		case R.id.summary_add_btn:
		try{
			TextView tv=(TextView)findViewById(R.id.inputtodo);
			
			LocateSummaryNode(tv.getText().toString().trim(),0);
			summary_Adapter.notifyDataSetChanged();
			spinner_adapter.notifyDataSetChanged();
			tv.setText("");
		}
		catch(Exception e){
			e.printStackTrace();
		}
    		
			break;
		case R.id.summary_delete_btn:
			
			SparseBooleanArray checkedItems=toDoList.getCheckedItemPositions();
			if(checkedItems.size()!=0)
			{
				
				
				for(int index=toDoList.getCount()-1;index>=0;index--)
				{
					if(checkedItems.get(index)){
						firstNode.commentList.remove(index);
						firstNode.nodeList.remove(index);
						SharedPreferences prefs=getSharedPreferences("user",Activity.MODE_PRIVATE);
						String url2="http://sejong.yarr.kr/index.php/api/get_nodes/"+prefs.getString("userNum","")
						+"/"+prefs.getString("token","")+"/"+saveData.getTeam_id();
						Comunication getnode=new Comunication(HIP_Manager.this,url2,"getnode");
						if(getnode.returnResult().equals("1")){
							
						Toast.makeText(HIP_Manager.this,getnode.returnMessage(), Toast.LENGTH_SHORT).show();
						
						}
						else if(getnode.returnResult().equals("0"))
							Toast.makeText(HIP_Manager.this,getnode.returnMessage(), Toast.LENGTH_SHORT).show();
						for(int i=0;i<getnode.returnnodeId().get(index).size();i++){
							
							node_id=getnode.returnnodeId().get(index).get(i);
							deleteNode();
						}
						lay.removeAllViews();
						arrangeSummary(-1);
						
					}
				}
				toDoList.clearChoices();
				LocateCircleAndText(firstNode,"start");
				summary_Adapter.notifyDataSetChanged();
				spinner_adapter.notifyDataSetChanged();
		}
			break;
			
		case R.id.newButton:
			
				
				TextView tv2=(TextView)findViewById(R.id.comment);
				
				if(tv2==null||tv2.length()==0){
					return;	
				}
				
				if(summaryspin.getSelectedItemPosition()<0){
					return;
				}
				int index=summaryspin.getSelectedItemPosition();
				addSubTree(tv2.getText().toString().trim(),index,0);
				
				tv2.setText("");
				break;
			
		case R.id.del:
			
			AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(HIP_Manager.this);
			TextView text=new TextView(v.getContext());
			text.setText("������ ���� �Ͻðڽ��ϱ�?\n(�ۼ��ڰ� �ƴҰ�� ������ �����ʽ��ϴ�)");
			alertDialogBuilder.setView(text);
			alertDialogBuilder.setCancelable(false)
					.setPositiveButton("��", new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int id) {
					
							deleteNode();
					    	for(int i=0;i<firstNode.nodeList.size();i++)
					    		for(int j=0;j<firstNode.nodeList.get(i).nodeList.size();j++){
					    			if(firstNode.nodeList.get(i).nodeList.get(j).getTag().toString().equals(node_id)){
					    				firstNode.nodeList.get(i).nodeList.remove(j);
					    				firstNode.nodeList.get(i).commentList.remove(j);
					    	  			
						    			lay.refreshDrawableState();
					    				break;
					    			}
					  
					    		}
								}
							})
			.setNegativeButton("�ƴϿ�", new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int id) {
			
							dialog.cancel();
						}
					});
			AlertDialog alert = alertDialogBuilder.create();
			alert.show();
	
		
	    	lay.removeAllViews();
			arrangeSummary(-1);
			break;
		case R.id.goodbtn:
			SharedPreferences prefs=getSharedPreferences("user",Activity.MODE_PRIVATE);
			StringBuilder u=new StringBuilder("http://sejong.yarr.kr/index.php/api/like_node?");
			u.append(String.format("user_number=%s",prefs.getString("userNum", "")));
			u.append(String.format("&token=%s",prefs.getString("token", "")));
			u.append(String.format("&node_id=%s",node_id));
			
			Comunication likenode=new Comunication(HIP_Manager.this,u.toString(),"likenode");
			if(likenode.returnResult().equals("1")){
			Toast.makeText(HIP_Manager.this,likenode.returnMessage(), Toast.LENGTH_SHORT).show();
			
			}
			else if(likenode.returnResult().equals("0"))
			Toast.makeText(HIP_Manager.this,likenode.returnMessage(), Toast.LENGTH_SHORT).show();
			break;
		case R.id.sosobtn:
			SharedPreferences p=getSharedPreferences("user",Activity.MODE_PRIVATE);
			StringBuilder url=new StringBuilder("http://sejong.yarr.kr/index.php/api/like_node?");
			url.append(String.format("user_number=%s",p.getString("userNum", "")));
			url.append(String.format("&token=%s",p.getString("token", "")));
			url.append(String.format("&node_id=%s",node_id));
			
			Comunication sosonode=new Comunication(HIP_Manager.this,url.toString(),"sosonode");
			if(sosonode.returnResult().equals("1")){
			Toast.makeText(HIP_Manager.this,sosonode.returnMessage(), Toast.LENGTH_SHORT).show();
			
			}
			else if(sosonode.returnResult().equals("0"))
			Toast.makeText(HIP_Manager.this,sosonode.returnMessage(), Toast.LENGTH_SHORT).show();
			break;
			
		case R.id.deadlinebtn:
			AlertDialog.Builder alertDialog = new AlertDialog.Builder(HIP_Manager.this);
			DatePicker date=new DatePicker(v.getContext());
			date.init(date.getYear(),
					date.getMonth(),
					date.getDayOfMonth(),
					new DatePicker.OnDateChangedListener() {
				@Override
				public void onDateChanged(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
						deadTime = String.format("%d / %d / %d", year,monthOfYear+1, dayOfMonth);
				}});
						

			alertDialog.setView(date);
			alertDialog.setCancelable(false)
					.setPositiveButton("��", new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int id) {
							Toast.makeText(HIP_Manager.this, deadTime, Toast.LENGTH_SHORT).show();
								}
							})
			.setNegativeButton("�ƴϿ�", new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int id) {
			
							dialog.cancel();
						}
					});
			AlertDialog alert2 = alertDialog.create();
			alert2.show();
			break;
		case R.id.donebtn:
			SparseBooleanArray check=toDoList.getCheckedItemPositions();
			int listP=0;
			if(check.size()!=0)
			{
				while(true)
				{
					
					if(check.get(listP)){
						
						break;
					}
					listP++;
					}
				lay.removeAllViews();
				arrangeSummary(listP);
				}
			toDoList.clearChoices();
			LocateCircleAndText(firstNode,"start");
			summary_Adapter.notifyDataSetChanged();
			spinner_adapter.notifyDataSetChanged();
			break;
			}
	}
			
	
	
	private void addData() {
		 ArrayList<Entry> yVal=new ArrayList<Entry>();
		   for(int i=0;i<yData.length;i++)
			   yVal.add(new Entry(yData[i],i));
		   
		   ArrayList<String> xVal=new ArrayList<String>();
		   for(int i=0;i<xData.length;i++)
			   xVal.add(xData[i]);
		   PieDataSet dataSet=new PieDataSet(yVal,"rate");
		   dataSet.setSliceSpace(3);
		   dataSet.setSelectionShift(5);
		   
		   ArrayList<Integer> colors=new ArrayList<Integer>();
		   for(int c : ColorTemplate.VORDIPLOM_COLORS)
			   colors.add(c);
		   for(int c : ColorTemplate.JOYFUL_COLORS)
			   colors.add(c);
		   for(int c : ColorTemplate.COLORFUL_COLORS)
			   colors.add(c);
		   for(int c : ColorTemplate.LIBERTY_COLORS)
			   colors.add(c);
		   for(int c : ColorTemplate.PASTEL_COLORS)
			   colors.add(c);
		   colors.add(ColorTemplate.getHoloBlue());
		   dataSet.setColors(colors);
		   PieData data=new PieData(xVal,dataSet);
		   data.setValueFormatter(new PercentFormatter());
		   data.setValueTextSize(11f);
		   data.setValueTextColor(Color.GRAY);
		   chart.setData(data);
		   chart.highlightValues(null);		   
		   
	}

	private void deleteNode(){
		SharedPreferences prefs=getSharedPreferences("user",Activity.MODE_PRIVATE);
		String url="http://sejong.yarr.kr/index.php/api/delete_node/"+prefs.getString("userNum","")
		+"/"+prefs.getString("token","")+"/"+node_id;
		Comunication delNode=new Comunication(HIP_Manager.this,url,"deletenode");
		if(delNode.returnResult().equals("1")){
		Toast.makeText(HIP_Manager.this,delNode.returnMessage(), Toast.LENGTH_SHORT).show();
	
		}
		else if(delNode.returnResult().equals("0"))
		Toast.makeText(HIP_Manager.this,delNode.returnMessage(), Toast.LENGTH_SHORT).show();
    	
	}
	
	

	private Node addSubTree(String tv,int index,int control) {
		
		SharedPreferences prefs=getSharedPreferences("user",Activity.MODE_PRIVATE);
		Node subTree=new Node(this,firstNode.nodeList.get(index));
		subTree.setTag(control);
		
	
		 Calendar calendar=Calendar.getInstance();
		 SimpleDateFormat datefomat=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			subTree.setTime(datefomat.format(calendar.getTime()));   
		    subTree.setUser(prefs.getString("userNum", ""));
		subTree.setOnClickListener(new View.OnClickListener(){
			public void onClick(View v){
				
				Node n=(Node)v;
				node_id=n.getNum();
				String n1=n.getTime();
				String n2=n.getUser();
				
				createDialog(n1,n2);

			}
		});
		firstNode.nodeList.get(index).nodeList.add(subTree);
		firstNode.nodeList.get(index).commentList.add(tv.toString());
		subTree.setX(subTree.getDepth()*DEPTH+STARTX);
		subTreeSetY(firstNode.nodeList.get(index));
		LocateCircleAndText(subTree,tv.toString());
		drawLineAtSub(firstNode.nodeList.get(index));
		
    	if(control==0){
    		
    		String url="http://sejong.yarr.kr/index.php/api/add_child_node?user_number="+prefs.getString("userNum","")
		+"&token="+prefs.getString("token","")+"&team_id="+saveData.getTeam_id()+"&main_node="+index+"&text_data="+tv;
		Comunication childnode=new Comunication(HIP_Manager.this,url,"childnode");
		if(childnode.returnResult().equals("1")){
		Toast.makeText(HIP_Manager.this,childnode.returnMessage(), Toast.LENGTH_SHORT).show();
		}
		else if(childnode.returnResult().equals("0"))
		Toast.makeText(HIP_Manager.this,childnode.returnMessage(), Toast.LENGTH_SHORT).show();
		
		
		/*if(firstNode.nodeList.get(index).nodeList.size()==0){
			DrawLine line=new DrawLine(this,firstNode.nodeList.get(index),subTree);
			lay.addView(line);
		}
		else{
			DrawLine line=new DrawLine(this,firstNode.nodeList.get(index).nodeList.get(firstNode.nodeList.get(index).nodeList.size()-1),subTree);
			lay.addView(line);
		}*/
		
		}
    	return subTree;
	}
	
	private void drawLineAtSub(Node n){
		if(n.nodeList.size()!=0){
		for(int i=0;i<n.nodeList.size();i++){
			DrawLine line;
			if(i==0){
				 line=new DrawLine(this,n,n.nodeList.get(i));
				
			}
			else{
				 line=new DrawLine(this,n.nodeList.get(i-1),n.nodeList.get(i));
			}
			lay.addView(line);
		}
		}
		
	}
	private void subTreeSetY(Node n){
		float parentGetY=n.getY();
		for(int i=0;i<n.nodeList.size();i++){
			n.nodeList.get(i).setY(parentGetY+DEPTH*(i+1));
		}
	}
	
	private void createDialog(String n1,String n2){
		LayoutInflater layoutInflater = LayoutInflater.from(HIP_Manager.this);
		View promptView = layoutInflater.inflate(R.layout.nodeclickview, null);
		TextView tv1=(TextView)promptView.findViewById(R.id.time);
		TextView tv2=(TextView)promptView.findViewById(R.id.user);
		tv1.setText("�ۼ��ð�   =  "+n1);
		tv2.setText("�ۼ���      =  "+n2);
		AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(HIP_Manager.this);
		alertDialogBuilder.setView(promptView);
	

		//final EditText editText = (EditText) promptView.findViewById(R.id.editTeamNameJ);
		// setup a dialog window
		alertDialogBuilder.setCancelable(false)
				.setPositiveButton("Ȯ��", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int id) {
				
								dialog.cancel();
							}
						});
		AlertDialog alert = alertDialogBuilder.create();
		alert.show();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.hip__manger, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	
	public void onTabChanged(String tabId)
	{
		for(int i =0; i<mTab.getTabWidget().getChildCount();i++)
		{
			mTab.getTabWidget().getChildAt(i).setBackgroundColor(Color.parseColor("#ffffff"));
		}
		mTab.getTabWidget().getChildAt(mTab.getCurrentTab()).setBackgroundColor(R.drawable.green_color);
	}
}


