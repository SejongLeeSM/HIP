package com.example.helperinproject;


import java.util.Random;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.DisplayMetrics;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class HIP_Login extends Activity {

   
   @Override
   protected void onCreate(Bundle savedInstanceState) {
      super.onCreate(savedInstanceState);
      this.requestWindowFeature(Window.FEATURE_NO_TITLE);   //�� ����
      setContentView(R.layout.activity_hip__login);
      StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
      StrictMode.setThreadPolicy(policy);
      
         
   
      }
      
   
   public void onStart(){
      super.onStart();
      SharedPreferences prefs=getSharedPreferences("user",Activity.MODE_PRIVATE);
      if(prefs.getString("token","").equals(""))
      {
         
      }
      else
      {
         Intent activity_messenger=new Intent(this,HIP_Messenger.class);
         startActivity(activity_messenger);
         this.finish();
      }
          
      }
   
   public void loginClickListener(View v)
   {

   switch(v.getId())
   {
   case R.id.introducing:
      Intent activity_intro=new Intent(this,HIP_Signup.class);
      startActivity(activity_intro);
      break;
      
   case R.id.loginBtn:
      if(checkInternet.getConnectivityStatus(this)==1||checkInternet.getConnectivityStatus(this)==2)
      {
      TextView id=(TextView)findViewById(R.id.login_id_input);
      TextView pw=(TextView)findViewById(R.id.login_ps_input);

      if(id.getText().length()!=0)
         if(pw.getText().length()!=0){
      String url="http://sejong.yarr.kr/index.php/api/login/"+id.getText().toString()+"/"+pw.getText().toString();
      Comunication intro=new Comunication(v.getContext(),url,"login");
      
      if(intro.returnResult().equals("1")){
      Toast.makeText(v.getContext(),intro.returnMessage(), Toast.LENGTH_SHORT).show();
      this.finish();
      Intent activity_messenger=new Intent(v.getContext(),HIP_Messenger.class);
      startActivity(activity_messenger);
      saveUser(intro.returnToken(),intro.returnId());
      
      }
      else if(intro.returnResult().equals("0")){
      Toast.makeText(v.getContext(),intro.returnMessage(), Toast.LENGTH_SHORT).show();
      }

      

   }
      else
         Toast.makeText(v.getContext(),"���� ���� Ȯ��!!", Toast.LENGTH_SHORT).show();
      
   }
      else if(checkInternet.getConnectivityStatus(this)==0)
         Toast.makeText(v.getContext(), "���ͳ� ���� Ȯ��", Toast.LENGTH_SHORT).show();
      break;
   }
   }
   
   
   private void saveUser(String token,String number){
      SharedPreferences prefs=getSharedPreferences("user",Activity.MODE_PRIVATE);
      SharedPreferences.Editor editor=prefs.edit();
      editor.putString("token",token);
      editor.putString("userNum", number);
        editor.commit(); 
   }
   
   @Override
   public boolean onCreateOptionsMenu(Menu menu) {
      // Inflate the menu; this adds items to the action bar if it is present.
      getMenuInflater().inflate(R.menu.hip__login, menu);
      return true;
   }  
   

   @Override
   public boolean onOptionsItemSelected(MenuItem item) {
      // Handle action bar item clicks here. The action bar will
      // automatically handle clicks on the Home/Up button, so long
      // as you specify a parent activity in AndroidManifest.xml.
      int id = item.getItemId();
      if (id == R.id.action_settings) {
         return true;
      }
      return super.onOptionsItemSelected(item);
   }
}