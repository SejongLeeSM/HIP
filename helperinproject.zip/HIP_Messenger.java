package com.example.helperinproject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.support.v4.view.ViewPager.LayoutParams;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class HIP_Messenger extends Activity
{
   
       private ArrayList<String> teamList = null;
       private ArrayList<String> memberList = null;
       private ListView listview;
       private ListView listview2;
       private List<String> team_id;
       ArrayAdapter<String> Adapter;//�����
       ArrayAdapter<String> Adapter2;//�����
       private BackPressCloseHandler backPressCloseHandler;

       int teamCodeIdx;
       
      
       
      
       
     
       @Override
       protected void onCreate(Bundle savedInstanceState) 
       {
          try{
          saveData.setTeam_index(-1);
          }
          catch(Exception e){
        	  e.printStackTrace();
          }
          SharedPreferences prefs=getSharedPreferences("user",Activity.MODE_PRIVATE);
          String url="http://sejong.yarr.kr/index.php/api/team_list/"+prefs.getString("userNum","")+"/"+prefs.getString("token","");
             
             Comunication teamlist=new Comunication(this,url,"teamlist");
             if(teamlist.returnResult().equals("1")){
             Toast.makeText(this,teamlist.returnMessage(), Toast.LENGTH_SHORT).show();
             
             }
             else if(teamlist.returnResult().equals("0"))
             Toast.makeText(this,teamlist.returnMessage(), Toast.LENGTH_SHORT).show();

            
             List<String> temp1=teamlist.returnteamName();
             team_id=teamlist.returnteamId();
             teamList = new ArrayList<String>();
             memberList=new ArrayList<String>();
             if(temp1!=null){
             for(int i=0;i<temp1.size();i++){
                teamList.add(temp1.get(i)+" / "+team_id.get(i));
             }
             
             }
             
             
                    
           super.onCreate(savedInstanceState);
           this.requestWindowFeature(Window.FEATURE_NO_TITLE);   //�� ����
           setContentView(R.layout.activity_hip__messenger);
           
           listview = (ListView)findViewById(R.id.memberTeam);
           listview2 = (ListView)findViewById(R.id.member);
           backPressCloseHandler = new BackPressCloseHandler(this);
           Adapter=new ArrayAdapter<String>(this,R.layout.itemcolor,teamList);
           Adapter2=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,memberList);
           listview.setAdapter(Adapter);
           Adapter.notifyDataSetChanged();
           listview2.setAdapter(Adapter2);
           
         listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
               @Override
               public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                  
                  try{

                     
                     saveData.setTeam_id(team_id.get(i));
                   saveData.setTeam_index(i);

                     SharedPreferences prefs=getSharedPreferences("user",Activity.MODE_PRIVATE);
                     
                     String url2="http://sejong.yarr.kr/index.php/api/team_member_list/"+prefs.getString("userNum","")+"/"+prefs.getString("token","")+"/"+team_id.get(i);
                   
                   Comunication memberlist=new Comunication(HIP_Messenger.this,url2,"memberlist");
                   if(memberlist.returnResult().equals("1")){
                   //Toast.makeText(SejongApp_messenger.this,memberlist.returnMessage(), Toast.LENGTH_SHORT).show();
                   
                   }
                   else if(memberlist.returnResult().equals("0"))
                   Toast.makeText(HIP_Messenger.this,memberlist.returnMessage(), Toast.LENGTH_SHORT).show();
                   
                   StringBuilder urlbuilder=new StringBuilder("http://sejong.yarr.kr/index.php/api/get_team_member_time_table?");
                   urlbuilder.append(String.format("user_number=%s",prefs.getString("userNum", "")));
                   urlbuilder.append(String.format("&token=%s",prefs.getString("token", "")));
                   urlbuilder.append(String.format("&team_id=%s",saveData.getTeam_id()));
                   Comunication memberState=new Comunication(HIP_Messenger.this,urlbuilder.toString(),"teamtimetable");
                   if(memberState.returnResult().equals("1")){
                       //Toast.makeText(SejongApp_messenger.this,memberlist.returnMessage(), Toast.LENGTH_SHORT).show();
                       
                       }
                       else if(memberState.returnResult().equals("0"))
                       Toast.makeText(HIP_Messenger.this,memberlist.returnMessage(), Toast.LENGTH_SHORT).show();
                   if(memberlist.returnuserId()!=null){
                      memberList.clear();
                      for(int x=0;x<memberlist.returnuserId().size();x++)
                      {
                         memberList.add(memberlist.returnuserId().get(x));
                      }
                      Adapter2.notifyDataSetChanged();
                      
                      }
                   
                   }
                   catch (Exception e){
                       e.printStackTrace();
                   }
                  view.setSelected(true);    
               }
           });
   

       }
     
       
       
       public class strImgSet
       {
          String name;
          int image;
          
          strImgSet(String aName, int aImage)
          {
             name = aName;
             image = aImage;
          }
          public String toString()
          {
             return name;
          }
       }
       
       @Override
      public boolean onCreateOptionsMenu(Menu menu) {
         // Inflate the menu; this adds items to the action bar if it is present.
         getMenuInflater().inflate(R.menu.hip__messenger, menu);
         return true;
      }

      @Override
      public boolean onOptionsItemSelected(MenuItem item) {
         // Handle action bar item clicks here. The action bar will
         // automatically handle clicks on the Home/Up button, so long
         // as you specify a parent activity in AndroidManifest.xml.
         int id = item.getItemId();
         if (id == R.id.action_settings) {
            return true;
         }
         return super.onOptionsItemSelected(item);
      }
      public void messengerClickListener(View v)
      {
         SharedPreferences prefs=getSharedPreferences("user",Activity.MODE_PRIVATE);
         switch(v.getId())
         {
      
         case R.id.createteambtn:
            createDialogText();
            break;
         case R.id.projectbtn:
            
            if(saveData.getTeam_index()!=-1){
               
                Handler handler = new Handler();
                 handler.postDelayed(new Runnable() {
                    ProgressDialog dialog= ProgressDialog.show(HIP_Messenger.this, "HIP","���� �ҷ�������",true);
                    public void run() {
                           Intent activity_manager=new Intent(HIP_Messenger.this,HIP_Manager.class);
                        startActivity(activity_manager);
                        dialog.dismiss();
                        }
                        

                        

                        
                    }, 1000);   

            
            //teamCode�� �ε������� ���� �� ������Ʈ������ �޾ƿ��� �ڵ� ¥����
            }
            break;
         case R.id.searchsharetimebtn:
            
            Toast.makeText(v.getContext(),prefs.getString("userNum", "") +"     "+ prefs.getString("token", ""), Toast.LENGTH_LONG).show();
            break;
            
            
         case R.id.jointeambtn:
            joinDialogText();

            break;
            
         case R.id.setbtn:
            //Intent activity_setting=new Intent(this,SejongApp_setting.class);
            //startActivity(activity_setting);
            //�α׾ƿ�
            
            SharedPreferences.Editor editor=prefs.edit();
             //editor.remove("token");
            editor.clear(); 
            editor.commit();
             Intent intent=new Intent(this,HIP_Login.class);
             startActivity(intent);
             this.finish();
            break;
         }
      }
      public void onBackPressed() {
         //super.onBackPressed();
         backPressCloseHandler.onBackPressed();
      }


public void createDialogText(){

   
   LayoutInflater layoutInflater = LayoutInflater.from(HIP_Messenger.this);
   View promptView = layoutInflater.inflate(R.layout.createteam, null);
   AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(HIP_Messenger.this);
   alertDialogBuilder.setView(promptView);

   final EditText editText = (EditText) promptView.findViewById(R.id.editTeamNameC);
   // setup a dialog window
   alertDialogBuilder.setCancelable(false)
         .setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
               
               if(editText.length()!=0){
                  AlertDialog.Builder alert_confirm = new AlertDialog.Builder(HIP_Messenger.this);
                  alert_confirm.setMessage("���� �����Ͻðڽ��ϱ�?").setCancelable(false).setPositiveButton("��",
                  new DialogInterface.OnClickListener() {
                      @Override
                      
                      public void onClick(DialogInterface dialog, int which) {
                         SharedPreferences prefs=getSharedPreferences("user",Activity.MODE_PRIVATE);
                        String url="http://sejong.yarr.kr/index.php/api/create_team?user_number="+prefs.getString("userNum","")+"&token="+prefs.getString("token", "")+"&team_name="+editText.getText().toString();
                        
                        Comunication createteam=new Comunication(HIP_Messenger.this,url,"createteam");
                        if(createteam.returnResult().equals("1")){
                        Toast.makeText(HIP_Messenger.this,createteam.returnMessage(), Toast.LENGTH_SHORT).show();
                        Intent activity_manager=new Intent(HIP_Messenger.this,HIP_Messenger.class);
                        startActivity(activity_manager);
                        HIP_Messenger.this.finish();
                        
                        
                        }
                        else if(createteam.returnResult().equals("0"))
                        Toast.makeText(HIP_Messenger.this,createteam.returnMessage(), Toast.LENGTH_SHORT).show();
                      }
                  }).setNegativeButton("�ƴϿ�",
                  new DialogInterface.OnClickListener() {
                      @Override
                      public void onClick(DialogInterface dialog, int which) {
                         dialog.cancel();
                      }
                  });
                  AlertDialog alert = alert_confirm.create();
                  alert.show();

               
            }
               else 
                  Toast.makeText(HIP_Messenger.this, "�Է°��� �����ϴ�",Toast.LENGTH_SHORT);
            }
         })
         .setNegativeButton("Cancel",
               new DialogInterface.OnClickListener() {
                  public void onClick(DialogInterface dialog, int id) {
                     dialog.cancel();
                  }
               });

   
   AlertDialog alert = alertDialogBuilder.create();
   alert.show();
}


public void joinDialogText(){

   
   LayoutInflater layoutInflater = LayoutInflater.from(HIP_Messenger.this);
   View promptView = layoutInflater.inflate(R.layout.jointeam, null);
   AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(HIP_Messenger.this);
   alertDialogBuilder.setView(promptView);

   final EditText editText = (EditText) promptView.findViewById(R.id.editTeamNameJ);
   // setup a dialog window
   alertDialogBuilder.setCancelable(false)
         .setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
               if(editText.length()!=0){
                  AlertDialog.Builder alert_confirm = new AlertDialog.Builder(HIP_Messenger.this);
                  alert_confirm.setMessage("���� �����Ͻðڽ��ϱ�?").setCancelable(false).setPositiveButton("��",
                  new DialogInterface.OnClickListener() {
                      @Override
                      public void onClick(DialogInterface dialog, int which) {
                         SharedPreferences prefs=getSharedPreferences("user",Activity.MODE_PRIVATE);
                        String url="http://sejong.yarr.kr/index.php/api/temp_team_signUp/"+prefs.getString("userNum", "")+"/"+prefs.getString("token", "")+"/"+editText.getText().toString();
                        
                        Comunication teamsignup=new Comunication(HIP_Messenger.this,url,"teamsignup");
                        if(teamsignup.returnResult().equals("1")){
                        Toast.makeText(HIP_Messenger.this,teamsignup.returnMessage(), Toast.LENGTH_SHORT).show();
                        Intent activity_manager=new Intent(HIP_Messenger.this,HIP_Messenger.class);
                        startActivity(activity_manager);
                        HIP_Messenger.this.finish();
                        }
                        else if(teamsignup.returnResult().equals("0"))
                        Toast.makeText(HIP_Messenger.this,teamsignup.returnMessage(), Toast.LENGTH_SHORT).show();
                     
                      }
                  }).setNegativeButton("�ƴϿ�",
                  new DialogInterface.OnClickListener() {
                      @Override
                      public void onClick(DialogInterface dialog, int which) {
                         dialog.cancel();
                      }
                  });
                  AlertDialog alert = alert_confirm.create();
                  alert.show();

                  
            }
               else 
                  Toast.makeText(HIP_Messenger.this, "�Է°��� �����ϴ�",Toast.LENGTH_SHORT);
            }
         })
         .setNegativeButton("Cancel",
               new DialogInterface.OnClickListener() {
                  public void onClick(DialogInterface dialog, int id) {
                     dialog.cancel();
                  }
               });

   
   AlertDialog alert = alertDialogBuilder.create();
   alert.show();
}

}
/*
   ExpandableListAdapter adapter_TeamMember;
   private ArrayList<String> teamName = null;
   private ArrayList<String> teamMember_Name = null;

   private ExpandableListView teamMemberListView;
   String[][] member_string=new String[][]{
      {"112190", "13011127"},
      {"����","����"},
      {"�̼���","������"}
      };
   
   @Override
   protected void onCreate(Bundle savedInstanceState) {
      super.onCreate(savedInstanceState);
      this.requestWindowFeature(Window.FEATURE_NO_TITLE);   //�� ����
      setContentView(R.layout.activity_sejong_app_messenger);
      
      
      teamName=new ArrayList<String>();
      teamMember_Name = new ArrayList<arraylist<string>>();
      
      teamName.add("��������");
      teamName.add("��������");
      teamName.add("��������");
      teamMemberListView=(ExpandableListView)findViewById(R.id.member);

      List<Map<String,String>> teamName_Data=new ArrayList<Map<String,String>>();
   List<List<Map<String,String>>> members_Data=new ArrayList<List<Map<String,String>>>();
   for(int i=0;i<teamName.size();i++)
   {
      Map<String,String> teamName_Map=new HashMap<String,String>();
      teamName_Map.put("teamName",teamName.get(i));
      teamName_Data.add(teamName_Map);
      
      List<Map<String,String>> member_Data=new ArrayList<Map<String,String>>();
      for(int j=0;j<member_string[i].length;j++)
      {
         Map<String,String> member_Map=new HashMap<String,String>();
         member_Map.put("member", member_string[i][j]);
         member_Data.add(member_Map);
      }
      members_Data.add(member_Data);
   }
   
   adapter_TeamMember=new SimpleExpandableListAdapter(
         this,
         teamName_Data,
         android.R.layout.simple_list_item_1,
         new String[]{"teamName"},
         new int[]{android.R.id.text1},
         members_Data,
         android.R.layout.simple_list_item_1,
         new String[]{"member"},
         new int[]{android.R.id.text1}
         );
   
   teamMemberListView.setAdapter(adapter_TeamMember);//
   //teamMemberListView.setAdapter(new BaseExpandableAdapter(this, teamName, teamMember_Name));
   teamMemberListView.setChoiceMode(ListView.CHOICE_MODE_SINGLE);   // ���ø�� ���� (�Ѱ���)
   teamMemberListView.setDivider(new ColorDrawable(Color.BLACK)); //���м� ���� ����
   teamMemberListView.setDividerHeight(10);   //���м� ���� ����
   
   }
   @Override
   public boolean onCreateOptionsMenu(Menu menu) {
      // Inflate the menu; this adds items to the action bar if it is present.
      getMenuInflater().inflate(R.menu.sejong_app_messanger, menu);
      return true;
   }

   @Override
   public boolean onOptionsItemSelected(MenuItem item) {
      // Handle action bar item clicks here. The action bar will
      // automatically handle clicks on the Home/Up button, so long
      // as you specify a parent activity in AndroidManifest.xml.
      int id = item.getItemId();
      if (id == R.id.action_settings) {
         return true;
      }
      return super.onOptionsItemSelected(item);
   }

}*/
